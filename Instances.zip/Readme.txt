This package contains the instances described in the paper:

Load-dependent Electric Vehicle Routing Problem with Time Window(2021), 
submitted to Sustainbility, Zhiguo Wu, Juliang Zhang.

We give a brief description of the package content. 

The instances are obtained as described in Section 5.1.

--  Benchmark Instances:
     
    ** Datas

    In Set 1 - 3,  the  type, x and y coordinates, demand, time windows and
	service time for each vertex are given. In the column "Type", d, c and  
	f denote the type of vertex, where d denotes depot, c  denotes cusotmer 
	and f denotes recharging station. The other papameters in benchmark
    are shown in Section 5.2.

    ** Distance
    
    Let x_ij = x_i - x_j and y_ij = y_i - y_j. The distance d_ij between 
	vertex i and vertex j is calculated by Euclidean distance. Specifically,  
     d_ij =sqrt( pow (x_ij*100, 2) + pow (y_ij*100, 2))/100

--  JD_data Instances:

     ** Datas 

     The column "x" and "y" denote the longitude and latitude. The description
	 of other columns in JD instance is the same as that in Set 1 - 3.
	 
	 ** Distance
	 
	 Let radx_i = x_i * pi / 180, rady_j = y_j * pi /180. x_ij = radx_i - radx_j and y_ij = rady_i - rady_j.
	 d_ij = 2R * arcsin(sqrt(pow(sin(y_ij/2),2) + cos(y_i) * cos(y_j) * pow(sin(x_ij/2),2))).
	 where R is the radius of the earth. R = 6371.004 km.
	 
	 
	 

    